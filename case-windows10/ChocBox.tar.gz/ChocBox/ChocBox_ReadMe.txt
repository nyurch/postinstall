Microsoft .NET Framework v4.7 or later is required
Run Check_.NET_version.cmd to check your version
ChocolateStore.exe is obtained from https://github.com/BahKoo/ChocolateStore
